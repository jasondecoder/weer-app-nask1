LIVE WEER — een weergave klaar voor een presentatie
=====================================================

WAT ERIN ZIT
- index.html — één op zichzelf staand bestand (HTML + CSS + JS).
  Geen build-stap, niets te installeren. Wel een internetverbinding
  nodig om OpenWeatherMap te bereiken en twee Google-lettertypes
  te laden.

EEN API-SLEUTEL AANVRAGEN
1. Meld je gratis aan op https://home.openweathermap.org/users/sign_up
2. Kopieer je API-sleutel via het tabblad "API keys" in je account.
3. Nieuwe sleutels kunnen enkele minuten (soms langer) nodig hebben
   om geactiveerd te worden — krijg je meteen na aanmelden een
   foutmelding, wacht dan even en probeer het opnieuw.

HOE JE HET GEBRUIKT
1. Open index.html in een moderne browser.
2. Bij de eerste keer opstarten wordt om je OpenWeatherMap
   API-sleutel gevraagd — plak deze erin. Hij wordt alleen lokaal
   in deze browser opgeslagen, dus je hoeft hem niet steeds opnieuw
   in te voeren.
3. De app probeert automatisch je locatie te gebruiken; zoek anders
   een stad in het veld bovenaan en druk op Enter.
4. Klik op het locatie-icoon om terug naar jouw locatie te gaan, op
   de °C/°F-knop om van eenheid te wisselen, en op het icoon voor
   volledig scherm vlak voor je presentatie — handig voor een
   beamer of tweede scherm.
5. Het tandwiel-icoon opent op elk moment opnieuw het scherm voor
   de API-sleutel (bijvoorbeeld om een typefout te herstellen).

WAT DE ACHTERGROND "LIVE" MAAKT
De achtergrond reageert op wat OpenWeatherMap op dit moment meldt:
- Heldere lucht krijgt driftende zonnestralen (dag) of twinkelende
  sterren (nacht)
- Bewolking krijgt zacht driftende wolkvormen
- Regen en motregen krijgen vallende regenstrepen
- Onweer krijgt regen plus willekeurige bliksemflitsen
- Sneeuw krijgt driftende sneeuwvlokken
- Mist/nevel/waas krijgt een zachte, driftende waas
Dag en nacht worden berekend op basis van de echte zonsopgang en
-ondergang van de stad, dus de sfeer klopt overal waar je zoekt.

Het geheel vernieuwt zichzelf elke 10 minuten, dus je kunt het
gerust op een scherm laten staan tijdens een live presentatie.

AANPASSEN
- Kleuren per weerscenario staan in het GRADIENTS-object onderin
  de <script>-tag — pas ze gerust aan.
- Verander de standaard reservestad ("Amsterdam") onderaan het
  script als je liever niet hebt dat het eerst locatie probeert
  te gebruiken.
